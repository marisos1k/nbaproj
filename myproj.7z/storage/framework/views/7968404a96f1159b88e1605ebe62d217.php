<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Редактировать <?php echo e($player->name); ?> - NBA Legends</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', 'resources/sass/app.scss']); ?>
    <style>
        .required::after {
            content: " *";
            color: red;
        }
        .img-thumbnail {
            border: 2px solid #dee2e6;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container">
            <a class="navbar-brand" href="/players">
                <img src="https://logos-world.net/wp-content/uploads/2020/11/NBA-Logo.png" height="40">
            </a>
            <a href="<?php echo e(route('players.index')); ?>" class="btn btn-outline-primary">
                ← Назад к карточке
            </a>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card shadow-lg">
                    <div class="card-header bg-warning text-dark">
                        <h4 class="mb-0">✏️ Редактировать игрока: <?php echo e($player->name); ?></h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('players.update', $player->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul class="mb-0">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="name" class="form-label required">Имя игрока</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="name" 
                                               name="name" 
                                               required
                                               value="<?php echo e(old('name', $player->name)); ?>"
                                               placeholder="Майкл Джордан">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="fullname" class="form-label">Полное имя</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="fullname" 
                                               name="fullname"
                                               value="<?php echo e(old('fullname', $player->fullname)); ?>"
                                               placeholder="Майкл Джеффри Джордан">
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="position" class="form-label">Позиция</label>
                                        <select class="form-select" id="position" name="position">
                                            <option value="">-- Выберите позицию --</option>
                                            <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($position); ?>" 
                                                    <?php echo e(old('position', $player->position) == $position ? 'selected' : ''); ?>>
                                                    <?php echo e($position); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="team" class="form-label">Команда</label>
                                        <select class="form-select" id="team" name="team">
                                            <option value="">-- Выберите команду --</option>
                                            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($team); ?>" 
                                                    <?php echo e(old('team', $player->team) == $team ? 'selected' : ''); ?>>
                                                    <?php echo e($team); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="number" class="form-label">Номер</label>
                                        <input type="number" 
                                               class="form-control" 
                                               id="number" 
                                               name="number"
                                               value="<?php echo e(old('number', $player->number)); ?>"
                                               min="0" 
                                               max="99"
                                               placeholder="23">
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="height" class="form-label">Рост</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="height" 
                                               name="height"
                                               value="<?php echo e(old('height', $player->height)); ?>"
                                               placeholder="198 см">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="weight" class="form-label">Вес</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="weight" 
                                               name="weight"
                                               value="<?php echo e(old('weight', $player->weight)); ?>"
                                               placeholder="98 кг">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="age" class="form-label">Возраст</label>
                                        <input type="number" 
                                               class="form-control" 
                                               id="age" 
                                               name="age"
                                               value="<?php echo e(old('age', $player->age)); ?>"
                                               min="16" 
                                               max="60"
                                               placeholder="35">
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="ppg" class="form-label">Очки за игру (PPG)</label>
                                        <input type="number" 
                                               class="form-control" 
                                               id="ppg" 
                                               name="ppg"
                                               value="<?php echo e(old('ppg', $player->ppg)); ?>"
                                               step="0.1"
                                               min="0"
                                               max="50"
                                               placeholder="30.1">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="rpg" class="form-label">Подборы за игру (RPG)</label>
                                        <input type="number" 
                                               class="form-control" 
                                               id="rpg" 
                                               name="rpg"
                                               value="<?php echo e(old('rpg', $player->rpg)); ?>"
                                               step="0.1"
                                               min="0"
                                               max="30"
                                               placeholder="6.2">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="apg" class="form-label">Передачи за игру (APG)</label>
                                        <input type="number" 
                                               class="form-control" 
                                               id="apg" 
                                               name="apg"
                                               value="<?php echo e(old('apg', $player->apg)); ?>"
                                               step="0.1"
                                               min="0"
                                               max="20"
                                               placeholder="5.3">
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="img_url" class="form-label">Ссылка на фото</label>
                                        <input type="url" 
                                               class="form-control" 
                                               id="img_url" 
                                               name="img_url"
                                               value="<?php echo e(old('img_url', $player->img_url)); ?>"
                                               placeholder="https://example.com/photo.jpg">
                                    </div>
                                </div>
                                
                                <?php if($player->img_url): ?>
                                <div class="col-md-6">
                                    <label class="form-label">Текущее фото:</label>
                                    <div>
                                        <img src="<?php echo e($player->img_url); ?>" 
                                             alt="<?php echo e($player->name); ?>" 
                                             class="img-thumbnail" 
                                             style="max-width: 200px;">
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-4">
                                <label for="bio" class="form-label">Биография</label>
                                <textarea class="form-control" 
                                          id="bio" 
                                          name="bio" 
                                          rows="4"
                                          placeholder="Опишите достижения и карьеру игрока..."><?php echo e(old('bio', $player->bio)); ?></textarea>
                            </div>

                            <div class="d-flex justify-content-between">
                                <div>
                                    <a href="<?php echo e(route('players.index')); ?>" class="btn btn-secondary">
                                        ← Отмена
                                    </a>
                                </div>
                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-warning">
                                        Сохранить изменения
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\UNIK\ORTPO\larfinal\myproject\resources\views/players/edit.blade.php ENDPATH**/ ?>